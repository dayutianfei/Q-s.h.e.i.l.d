package cn.dayutianfei.loadserver.common;

public class Codes {
    public static final String LOAD_DATA = "10000";
    public static final String LOAD_DATA_SUCCESS = "10001";
    public static final String LOAD_DATA_FAILURE = "10002";
    public static final String FLUSH_DATA = "20000";
    public static final String FLUSH_DATA_SUCCESS = "20001";
    public static final String FLUSH_DATA_FAILURE = "20002";
}
