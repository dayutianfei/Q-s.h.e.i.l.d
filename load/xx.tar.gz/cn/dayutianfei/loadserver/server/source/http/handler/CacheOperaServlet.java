package cn.dayutianfei.loadserver.server.source.http.handler;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.dayutianfei.loadserver.server.LoadServerCache;


public class CacheOperaServlet extends HttpServlet {
    private static final Logger LOG = LoggerFactory.getLogger(CacheOperaServlet.class);
    
    private static final long serialVersionUID = 1L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*
         * Get headers from http query string, and get body from http post
         * content.
         */
        int totalLength = request.getContentLength();
        if (totalLength <= 0) {
            LOG.warn("content length: " + totalLength);
        }
        
        response.setContentType("text/html");  
        response.setStatus(HttpServletResponse.SC_OK);
        if(null != request.getParameter(LoadServerCache.OperaType.ADDHOST.toString())){
            LoadServerCache.addBackendHost(request.getParameter(LoadServerCache.OperaType.ADDHOST.toString()));
        }else if(null != request.getParameter(LoadServerCache.OperaType.REMOVEHOST.toString())){
            LoadServerCache.removeBackendHost(request.getParameter(LoadServerCache.OperaType.REMOVEHOST.toString()));
        }else{
            if(LoadServerCache.hostName.isEmpty()){
                response.getWriter().println("<h1>no host in cache</h1>");
                response.getWriter().println("<h2>you can add a host name or ip use </h2>");
                response.getWriter().println("<h2>http://ip:port/cache/opera=value</h2>");  
            }else{
                for(String host: LoadServerCache.hostName){
                    response.getWriter().println("<h1>" + host + "</h1>");  
                }
            }
            response.getWriter().println("session=" + request.getSession(true).getId());  
        }
        response.setCharacterEncoding(request.getCharacterEncoding());
        response.flushBuffer();
    }


    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }
}
